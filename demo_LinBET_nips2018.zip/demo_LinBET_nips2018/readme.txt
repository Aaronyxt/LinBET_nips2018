1. This is a demo for S1 in paper `Almost Optimal Algorithms for Linear Stochastic Bandits with Heavy-Tailed Payoffs', which is published in NIPS 2018.

2. The platform should run under Python 3.0+

3. Open demo.py and Run.

4. One should generate other datasets based on the paper, and can test the performance of algorithms.

