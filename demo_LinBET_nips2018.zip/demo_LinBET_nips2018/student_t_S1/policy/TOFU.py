# -*- coding: utf-8 -*-

import numpy as np
#from policy.IndexPolicy import IndexPolicy
from random import choice
from scipy.linalg import fractional_matrix_power

class TOFU():
    """The TOFU.
    """

    def __init__(self, nb_arms, nb_features):
        self.name = "TOFU"
        self.nb_arms = nb_arms
        self.nb_features = nb_features
        self.lambda1 = 1
        self.X = np.matrix(np.eye(self.nb_features))*self.lambda1
        self.b = np.matrix(np.zeros(self.nb_features))
        self.gamma = 1

        # parameters for truncations
        self.delta = 0.1
        self.alpha = 1.0
        self.beta = 1.0 + np.zeros(self.nb_arms)
        
    def start_game(self, env):
        self.T = env.horizon
        self.t = 1
        self.truncat_nb = 0
        self.A = np.log(np.sqrt(1+float(self.t/self.nb_features))/self.delta)
        self.order = env.order
        self.stat = env.truth['stat'] # [p,B,C]
        self.arms_stat = env.arms_stat
        self.B = self.stat[1]
        
        self.alpha = (self.B/np.log(2.0*self.nb_features*(self.t**2)/self.delta))**(1/self.order)*(self.t**((2-self.order)/(2*self.order)))
        self.Xt = np.zeros([1,self.nb_features])
        self.Yt = np.zeros([1,1])
        
        self.beta = 4*np.sqrt(self.nb_features)*(self.B**(1/self.order))*((np.log(2*self.nb_features*(self.t**2)/self.delta))**((self.order-1)/self.order))*(self.t**((2-self.order)/(2*self.order))) + np.sqrt(self.gamma*self.nb_features)
#        print('beta: ', self.beta)
#        print(aa)
        self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))

    def get_reward(self, armid, arm, reward):
        
        if self.t==1:
            self.Xt[0,:] = np.copy(arm)
            self.Yt[0,:] = np.copy(reward)
        else:
            self.Xt = np.vstack([self.Xt, arm])
            self.Yt = np.vstack([self.Yt, reward])
        FMP = fractional_matrix_power(self.X, -0.5)
        U = FMP*np.matrix(self.Xt).transpose()
        
        
        Y = np.repeat(self.Yt,self.nb_features,axis=1)
        UY = np.zeros(self.nb_features)
        
        self.truncat_nb = 0
        for s in range(self.t):
            for i in range(self.nb_features):
                if U[i,s]*self.Yt[s,0]>self.alpha: # truncation on payoffs
                    Y[s,i] = 0
                    self.truncat_nb += 1
                    
        for i in range(self.nb_features):
            UY[i] = (np.matrix(U[i,:])*np.matrix(Y[:,i]).transpose()).item(0,0)
            
        self.theta = FMP*np.matrix(UY).transpose()
            
        
        self.t += 1
        self.alpha = (self.B/np.log(2.0*self.nb_features*(self.t**2)/self.delta))**(1/self.order)*(self.t**((2-self.order)/(2*self.order)))
        self.beta = 4*np.sqrt(self.nb_features)*(self.B**(1/self.order))*((np.log(2*self.nb_features*(self.t**2)/self.delta))**((self.order-1)/self.order))*(self.t**((2-self.order)/(2*self.order))) + np.sqrt(self.gamma*self.nb_features)
#        self.beta = 2*np.sqrt(self.t**(1/self.order)*(self.A+self.B**np.log(self.T))*np.log(1+self.T/self.nb_features))
#        print('alpha: ', self.alpha)
#        print('beta: ', self.beta)
#        print(aa)

    def compute_index(self, armid, arm):
        result= (self.theta.transpose()*np.matrix(arm).transpose()).item(0,0)+self.beta*np.sqrt((np.matrix(arm)*np.linalg.inv(self.X)*np.matrix(arm).transpose()).item(0,0)) 
        return result
    
    def choice_index(self, arms_context):
        index = dict()     
        for arm in range(self.nb_arms):
            index[arm] = self.compute_index(arm, arms_context[arm])
            #print("index: ", index[arm])
        max_index = max (index.values())
        best_arms = [arm for arm in index.keys() if index[arm] == max_index]
        return choice(best_arms)