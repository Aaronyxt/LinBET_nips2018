# -*- coding: utf-8 -*-

import numpy as np
from scipy.special import btdtri

class GaussianPosterior:
    """
    Gaussian posterior for contextual bandits
    """
    def __init__(self, mu, cov):
        self.mu = mu
        self.cov = cov
        
    def update(self, mu, cov):
        self.mu = mu
        self.cov = cov
        
    def sample(self):
        return np.random.multivariate_normal(self.mu, self.cov, 1)[0]