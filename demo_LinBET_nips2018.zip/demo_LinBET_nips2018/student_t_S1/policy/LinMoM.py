# -*- coding: utf-8 -*-

import numpy as np
import math
#from policy.IndexPolicy import IndexPolicy
from random import choice

class LinMoM():
    """The LinMoM.
      Reference1: [Medina, Yang - ICML, 2016].
    """

    def __init__(self, nb_arms, nb_features):
        self.name = "MoM"
        self.nb_arms = nb_arms
        self.nb_features = nb_features
        self.lambda1 = 1
        self.X = np.matrix(np.eye(self.nb_features))*self.lambda1
        self.b = np.matrix(np.zeros(self.nb_features))
        self.gamma = 1

        # parameters for truncations
        self.delta = 0.1
        self.alpha = 1.0
        self.beta = 1.0 + np.zeros(self.nb_arms)
        
    def start_game(self, env):
        self.T = env.horizon
        self.t = 1
        self.truncat_nb = 0
        
        self.order = env.order
        self.stat = env.truth['stat'] # [p,B,C]
        self.arms_stat = env.arms_stat
        self.B = self.stat[1]
        self.C = self.stat[2]
        
        self.nb_batch = int(self.T**(2*(self.order-1)/(3*self.order-2)))
        self.nb_rep = math.floor(self.T/self.nb_batch)
        self.count = 1
        self.lock = False
        self.lock_payoffs = np.zeros(self.nb_rep)
        self.i = 1
        
        self.LinCR = np.sqrt(2*np.log(self.nb_batch*((np.linalg.det(self.X))**0.5)/self.delta)) + np.sqrt(self.i)
        self.beta = (12*self.C)**(1.0/self.order)*(8*np.log(2*self.nb_batch/self.delta)/self.nb_rep)**((self.order-1)/self.order)*self.LinCR + 1
#        print('alpha: ', self.alpha)
#        print('beta: ', self.beta)
#        print(aa)
        self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))

    def get_reward(self, armid, arm, reward):
        if (not self.lock) and (self.count == 1):
            self.lock = True
            self.lock_id = armid
        
        if self.lock:
            self.lock_payoffs[self.count-1] = reward
            self.count += 1
            
        if self.lock and (self.count == self.nb_rep):
            self.count = 1
            self.lock = False
            
            self.X += np.matrix(arm).transpose()*np.matrix(arm)
            update_reward = self.MoM(self.lock_payoffs)
            self.b += np.matrix(arm)*update_reward
            self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))
            
            self.LinCR = np.sqrt(2*np.log(self.nb_batch*((np.linalg.det(self.X))**0.5)/self.delta)) + np.sqrt(self.i)
            self.beta = (12*self.C)**(1.0/self.order)*(8*np.log(2*self.nb_batch/self.delta)/self.nb_rep)**((self.order-1)/self.order)*self.LinCR + 1
#            print('name ', self.name)
#            print('beta ', self.beta)
            self.i += 1


        self.t += 1
#        self.beta = 2*np.sqrt(self.t**(1/self.order)*(self.A+self.B**np.log(self.T))*np.log(1+self.T/self.nb_features))
#        print('alpha: ', self.alpha)
#        print('beta: ', self.beta)
#        print(aa)

    def MoM(self, payoffs):
        k = math.floor(8*np.log(2/self.delta))
        N = math.floor(self.nb_rep/k)
        new_reward = np.zeros(k)
        for i in range(k):
            new_reward[i] = 0
            for j in range(N):
                new_reward[i] += payoffs[i*N+j]
            new_reward[i] = new_reward[i]/N
        return np.median(new_reward)
        
    def compute_index(self, armid, arm):    
        if self.lock:
            if armid == self.lock_id:
                return 1.0
            else:
                return 0.0
        else:
            result= (self.theta.transpose()*np.matrix(arm).transpose()).item(0,0)+self.beta*np.sqrt((np.matrix(arm)*np.linalg.inv(self.X)*np.matrix(arm).transpose()).item(0,0))
        return result
    
    def choice_index(self, arms_context):
        index = dict()     
        for arm in range(self.nb_arms):
            index[arm] = self.compute_index(arm, arms_context[arm])
            #print("index: ", index[arm])
        max_index = max (index.values())
        best_arms = [arm for arm in index.keys() if index[arm] == max_index]
        return choice(best_arms)