# -*- coding: utf-8 -*-

import numpy as np
#from policy.IndexPolicy import IndexPolicy
from random import choice

class LinCRT():
    """The LinCRT.
      Reference1: [Medina, Yang - ICML, 2016].
    """

    def __init__(self, nb_arms, nb_features):
        self.name = "CRT"
        self.nb_arms = nb_arms
        self.nb_features = nb_features
        self.lambda1 = 1
        self.X = np.matrix(np.eye(self.nb_features))*self.lambda1
        self.b = np.matrix(np.zeros(self.nb_features))
        self.gamma = 1

        # parameters for truncations
        self.delta = 0.1
        self.alpha = 1.0
        self.beta = 1.0 + np.zeros(self.nb_arms)
        
    def start_game(self, env):
        self.T = env.horizon
        self.t = 1
        self.truncat_nb = 0
        self.A = np.log(np.sqrt(1+float(self.T/self.nb_features))*(self.t**2)/self.delta)
        self.order = env.order
        self.stat = env.truth['stat'] # [p,B,C]
        self.arms_stat = env.arms_stat
        self.B = self.stat[1]
        self.alpha = self.t**(1/(2*self.order))
        self.beta = 2*np.sqrt(self.t**(1/self.order)*(self.A+self.B**np.log(self.t))*np.log(1+self.t/self.nb_features))+1
#        print('alpha: ', self.alpha)
#        print('beta: ', self.beta)
#        print(aa)
        self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))

    def get_reward(self, armid, arm, reward):
        if abs(reward) >= self.alpha:
            self.truncat_nb += 1
            reward = 0.0
            
        self.X += np.matrix(arm).transpose()*np.matrix(arm)
#        print(type(arm))
#        print(type(reward))
#        print(reward)
        self.b += np.matrix(arm)*reward
        self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))
        
        self.t += 1
        self.A = np.log(np.sqrt(1+float(self.T/self.nb_features))*(self.t**2)/self.delta)
        self.alpha = self.t**(1/(2*self.order))
        self.beta = 2*np.sqrt(self.t**(1/self.order)*(self.A+self.B**np.log(self.t))*np.log(1+self.t/self.nb_features))+1
#        self.beta = 2*np.sqrt(self.t**(1/self.order)*(self.A+self.B**np.log(self.T))*np.log(1+self.T/self.nb_features))
#        print('alpha: ', self.alpha)
#        print('beta: ', self.beta)
#        print(aa)

    def compute_index(self, armid, arm):    
        result= (self.theta.transpose()*np.matrix(arm).transpose()).item(0,0)+self.beta*np.sqrt((np.matrix(arm)*np.linalg.inv(self.X)*np.matrix(arm).transpose()).item(0,0)) 
        return result
    
    def choice_index(self, arms_context):
        index = dict()     
        for arm in range(self.nb_arms):
            index[arm] = self.compute_index(arm, arms_context[arm])
            #print("index: ", index[arm])
        max_index = max (index.values())
        best_arms = [arm for arm in index.keys() if index[arm] == max_index]
        return choice(best_arms)