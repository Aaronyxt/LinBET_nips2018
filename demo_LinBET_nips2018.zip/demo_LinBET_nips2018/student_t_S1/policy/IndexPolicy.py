# -*- coding: utf-8 -*-

from random import choice
import numpy as np

class IndexPolicy:
    def __init__(self, data):
        self.arms_context = data.arms_id
        self.nb_arms = data.nb_arms
        self.nb_features = data.nb_features
        
        self.p = data.p
        self.B = data.B
        self.C = data.C