# -*- coding: utf-8 -*-

import numpy as np
#from policy.IndexPolicy import IndexPolicy
from random import choice

class LinUCB():
    """The LinUCB.
      Reference1: [Li, Chu, Langford and Schapire - WWW, 2010].
      Reference2: [Chu, Li, Reyzin and Schapire - AISTATS, 2011].
    """

    def __init__(self, nb_arms, nb_features):
        self.name = "LinUCB"
        self.nb_arms = nb_arms
        self.nb_features = nb_features
        self.lambda1 = 1.0
        self.X = np.matrix(np.eye(self.nb_features))*self.lambda1
        self.b = np.matrix(np.zeros(self.nb_features))
        self.delta = 0.1
        self.gamma = 1.0
        
    def start_game(self, env):
        self.T = env.horizon
        self.t = 1
        self.truncat_nb = 0
        self.gamma = np.sqrt(self.nb_features*np.log(self.t/self.delta))
        self.theta = np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))

    def get_reward(self, armid, arm, reward):
        self.X+=np.matrix(arm).transpose()*np.matrix(arm)
#        print(type(arm))
#        print(type(reward))
#        print(reward)
        self.b+=np.matrix(arm)*reward
        self.theta=np.linalg.inv(self.X)*np.transpose(np.matrix(self.b))
        self.t += 1
        self.gamma = np.sqrt(self.nb_features*np.log(self.t/self.delta))
#        print(aa)

    def compute_index(self, armid, arm):    
        result= (self.theta.transpose()*np.matrix(arm).transpose()).item(0,0)+self.gamma*np.sqrt((np.matrix(arm)*np.linalg.inv(self.X)*np.matrix(arm).transpose()).item(0,0)) 
        return result
    
    def choice_index(self, arms_context):
        index = dict()     
        for arm in range(self.nb_arms):
            index[arm] = self.compute_index(arm, arms_context[arm])
            #print("index: ", index[arm])
        max_index = max (index.values())
        best_arms = [arm for arm in index.keys() if index[arm] == max_index]
        return choice(best_arms)