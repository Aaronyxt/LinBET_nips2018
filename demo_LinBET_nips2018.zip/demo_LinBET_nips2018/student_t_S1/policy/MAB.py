# -*- coding: utf-8 -*-

import numpy as np
from policy.IndexPolicy import IndexPolicy

class MABSRT(IndexPolicy):

    def __init__(self, data, setting, parameter):
        IndexPolicy.__init__(self, data)
        self.arm_est = {}
        for arm in range(self.nb_arms):
            self.arm_est.update({arm:[]})
        self.T = 0
        self.decision_set = [k for k in range(self.nb_arms)]
        
        self.logK = 1.0/2+sum([1.0/k for k in range(2,self.nb_arms+1)])
        self.t = 0
        self.phrases = np.zeros(self.nb_arms)

        self.setting = setting
        if self.setting == 'b':
            self.horizon = parameter 
        else:
            self.delta = parameter
            
    def start_game(self, env, horizon):
        self.arm_est = {}
        for arm in range(self.nb_arms):
            self.arm_est.update({arm:[0,0]})
        self.phrases = np.zeros(self.nb_arms)
        for k in range(1,self.nb_arms):
            self.phrases[k] = (horizon-self.nb_arms)/((self.nb_arms+1-k)*(self.logK))
        self.phrases = np.ceil(self.phrases)
        return self.phrases
    
    def get_time_index(self, arm_id):
        return len(self.arm_est[arm_id])
    
    def restart_decision_set(self):
        self.decision_set = [k for k in range(self.nb_arms)]
    
    def get_decision_set(self):
        return self.decision_set

    def get_reward(self, env, arm_id, arm, reward):
        count = self.arm_est[arm_id][1]
        self.arm_est[arm_id][1] += 1
        self.arm_est[arm_id][0] = (count*self.arm_est[arm_id][0] + reward)/(count + 1)
    
    def update_decision_set(self, action):
        self.decision_set.remove(action)
    
    def compute_index(self, env, arm_id, arm):
        return self.arm_est[arm_id][0]