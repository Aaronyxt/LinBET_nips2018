# -*- coding: utf-8 -*-

import numpy as np
from policy.IndexPolicy import IndexPolicy

class MABTEA(IndexPolicy):

    def __init__(self, data, setting, parameter):
        IndexPolicy.__init__(self, data)
        
        self.arm_est = {}
        self.arm_info = {}
        self.setting = setting
        if self.setting == 'b':
            self.horizon = parameter 
            self.name = 'SR-$T$(TEA)'
        else:
            self.delta = parameter
            self.name = 'SE-$\delta$(TEA)'
          
        # self.p, self.B, self.C and self.Delta are obtained via data oracle    
        
    def start_game(self, env):
        self.arm_est = {}
        for arm in range(self.nb_arms):
            self.arm_est.update({arm:[0,0]})
            self.arm_info.update({arm:[]})
        
        self.b_t = 10**3 # initialization of b_t, will be updated later
        self.trancated_index = dict()  
        
        self.decision_set = [k for k in range(self.nb_arms)]
        if self.setting == 'b':
            self.logK = 1.0/2+sum([1.0/k for k in range(2,self.nb_arms+1)])
            self.phrases = np.zeros(self.nb_arms)
            for k in range(1,self.nb_arms):
                self.phrases[k] = (self.horizon-self.nb_arms)/((self.nb_arms+1-k)*(self.logK))
            self.phrases = np.ceil(self.phrases)
            return self.phrases
        else:
            return self.arm_est
    
    def get_time_index(self, arm_id):
        return len(self.arm_est[arm_id])
    
    def restart_decision_set(self):
        self.decision_set = [k for k in range(self.nb_arms)]
    
    def get_decision_set(self):
        return self.decision_set
    
    def set_confidence_bound(self, arm_id):
        count = self.arm_est[arm_id][1]
        
        if self.p <= 2:
            c_t = 5*(self.B**(1/self.p))*(np.log(2*self.nb_arms/self.delta)/count)**((self.p-1)/self.p)
            self.b_t = (self.B*count/(np.log(2*self.nb_arms/self.delta)))**(1/self.p) 
        else:
            c_t = ((5*self.B/count**(self.p/2))**(1/self.p))*((np.log(2*self.nb_arms/self.delta))**((self.p-1)/self.p))
            self.b_t = (self.B*(count)**(self.p/2)/(np.log(2*self.nb_arms/self.delta)))**(1/self.p)
        return c_t
    
    def get_reward(self, env, arm_id, arm, reward):
        count = self.arm_est[arm_id][1]
        self.arm_est[arm_id][1] = count + 1
        
        m = count*self.arm_est[arm_id][0]
        
        if self.setting == 'b':
             if self.p <= 2:
                 self.b_t = (3*self.B*self.p/self.Delta)**(1.0/(self.p-1))
             else:
                 self.b_t = 2*(2*self.B+self.B**(2.0/self.p))/self.Delta

        if np.abs(reward)<=self.b_t:
            self.arm_est[arm_id][0] = (m+reward)/(count+1)
        else:
            self.arm_est[arm_id][0] = m/(count+1)
            self.trancated_index.update({count:reward})

                    
    def number_trancated(self):
        return len(self.trancated_index)
    
    def update_decision_set(self, action):
        self.decision_set.remove(action)
    
    def compute_index(self, arm_id):
        return self.arm_est[arm_id][0]