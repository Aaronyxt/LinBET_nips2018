# -*- coding: utf-8 -*-


class arm:
    def __init__(self): 
        self.expectation = 1.0
        self.variance = 1.0
        
    def draw(self): 
        pass
