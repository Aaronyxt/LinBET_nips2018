# -*- coding: utf-8 -*-
'''Arm with Gaussian distribution.'''


import numpy as np
from environment.arms.arm import arm

class Gaussian(arm):
    def __init__(self, mu, sigma):
        self.mu = mu
        self.variance = sigma
        self.expectation = mu
        
    def draw(self):
        return np.asscalar(np.random.normal(self.mu, np.sqrt(self.variance), 1))
