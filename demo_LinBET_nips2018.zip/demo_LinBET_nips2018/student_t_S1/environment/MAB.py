# -*- coding: utf-8 -*-

from environment.arms.Bernoulli import Bernoulli
from environment.arms.Gaussian import Gaussian
from environment.arms.Exponential import Exponential
from environment.arms.StudentT import StudentT
import numpy as np
import random

class MAB:    
    def __init__(self, data, nb_rep, horizon):
        self.nb_repetitions = nb_rep
        self.horizon = horizon
        self.arms_id = data.arms_id
        
        self.nb_arms = data.nb_arms
        self.nb_features = data.nb_features
        self.arms_id = data.arms_id
        self.order = data.p
        self.truth = data.truth # contain B and C over all arms
        self.arms_stat = data.arms_stat # contain B and C for each arms

                              
        # if payoff is automatically generated, one should construct arm machine. Otherwise, just self.truth
        self.payoff_format = data.payoff_format # generate or read
        if self.payoff_format == 'generate':
            self.arms_machine = {}
            self.generate_arms()
        else:
            self.arms_machine = {}
            self.generate_arms_real_data()
            
        # data mode for randomized experiemntal setting
#        self.mode = data.mode
        
    def generate_arms(self):  # for stochastic generated payoffs
        for arm in range(self.nb_arms):
            #print(self.truth[arm][0],self.truth[arm][1])
#            print('truth: ', self.truth['theta'])
#            print('arm: ', self.arms_id[arm])
            m = np.dot(self.truth['theta'],self.arms_id[arm])
            self.arms_machine.update({arm:StudentT(m,self.order,1)})
    
    def generate_arms_real_data(self):  # for stochastic generated payoffs
        for arm in range(self.nb_arms):
            #print(self.truth[arm][0],self.truth[arm][1])
            self.arms_machine.update({arm:StudentT(self.truth_stat[arm][0],self.truth_stat[arm][1], self.truth_stat[arm][2])})        
            #self.arms_machine.update({arm:Bernoulli(self.truth[arm][0])})
                
    def generate_payoff(self, arm_id):
        if self.payoff_format == 'generate':
            reward = self.arms_machine[arm_id].draw()
            return reward
        
#        if self.payoff_format == 'read' and self.setting == 'b':        
#            samples = len(self.truth[arm_id])
#            point = random.randint(0,samples-1)
#            return self.truth[arm_id][point]
#        else:
#            reward = self.arms_machine[arm_id].draw()
#            return reward
    def best_arm_payoff(self):  
        best_mean = 0
        best_arm = 0
        for arm in range(self.nb_arms):
            m = np.dot(self.truth['theta'],self.arms_id[arm])
            if m>best_mean:
                best_mean = np.copy(m)
                best_arm = np.copy(arm)
        return [best_arm, best_mean]
    
    def worst_arm_payoff(self):  
        worst_mean = 100
        worst_arm = 0
        for arm in range(self.nb_arms):
            m = np.dot(self.truth['theta'],self.arms_id[arm])
            if m<worst_mean:
                worst_mean = np.copy(m)
                worst_arm = np.copy(arm)
        return [worst_arm, worst_mean]