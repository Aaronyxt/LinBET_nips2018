# -*- coding: utf-8 -*-

import numpy as np
import os

class LoadArmParameter:
    def __init__(self):
        self.arms_id = {}
        self.truth = {} # we save the parameter in truth
        self.payoff_format = 'generate' # generate or read
        self.arm_state = 'read' # read or generate
        self.arms_stat = {}
        
        self.nb_arms = 20
        self.nb_features = 10
        self.generate_arms = False
        
        # parameters will be updated
        self.p = 2 # p-th order
        self.B = 3 # raw moment
        self.C = 3 # central moment
        
        path = os.getcwd() + '/data/' 
        if self.generate_arms:
            with open(path+"Arm.txt",'w') as f:    
                for arm in range(self.nb_arms):
                    a = np.random.rand(self.nb_features)
                    self.arms_id.update({arm:a})
                    f.writelines(["%s " % item  for item in a])
                    f.write('\n')
            with open(path+"Parameter.txt",'w') as f:    
                a = np.random.rand(self.nb_features)
                self.truth.update({'theta':a})
                f.writelines(["%s " % item  for item in a])
                f.write('\n')
        else:
            with open(path+"Arm.txt",'r') as f:    
                arm = 0
                for line in f:
                    lstr = line.strip().split()
                    arm_context = [float(d) for d in lstr]
                    self.arms_id.update({arm:np.array(arm_context)})
                    arm += 1
            with open(path+"Parameter.txt",'r') as f:
                for line in f:
                    lstr = line.strip().split()
                    p = [float(d) for d in lstr]
                    self.truth.update({'theta':np.array(p)})
                    
        # update parameters
        best_mean = 0
        best_B = 0
        best_C = np.copy(self.C)
        best_p = np.copy(self.p)
        for arm in range(self.nb_arms):
            m = np.dot(self.truth['theta'],self.arms_id[arm])
            self.arms_stat.update({arm:[self.p,self.C+m**2,self.C]})
            if m>best_mean:
                best_mean = np.copy(m)
        best_B = best_C + m**2
        self.truth.update({'stat':[best_p,best_B,best_C]})
        self.B = best_B
        self.C = best_C