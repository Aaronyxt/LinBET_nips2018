# -*- coding: utf-8 -*-

import random
import numpy as np

from evaluation.Result import *

class Evaluation:
  
    def __init__(self, env, pol, nb_rep, horizon):
        self.env = env
        self.policy = pol
        self.nb_repetitions = nb_rep
        self.horizon = horizon
        self.nb_arms = env.nb_arms
        self.nb_features = env.nb_features
        self.arms_id = env.arms_id
        
        self.nb_pulls = np.zeros([self.nb_arms, self.nb_repetitions])
        self.cum_reward = np.zeros((self.nb_repetitions, self.horizon))
      
    def play(self, policy):
        result = Result(self.nb_arms, self.nb_repetitions, self.horizon)
        for rep in range(self.nb_repetitions):
            self.policy.start_game(self.env)
                
            for t in range(self.horizon):  
                choice = policy.choice_index(self.env.arms_id)
                f_c = choice
                reward = self.env.generate_payoff(f_c)
                policy.get_reward(f_c, self.arms_id[f_c], reward)
                result.store_rewards(rep, t, f_c, reward, 1)
            print('truncated num: ', policy.truncat_nb)
        result.calculate_stat_rewards()
        return result
        