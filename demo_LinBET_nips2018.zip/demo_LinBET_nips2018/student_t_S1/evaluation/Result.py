# -*- coding: utf-8 -*-

import numpy as np

class Result:
    """The Result class for analyzing regret in sequential decisions."""
    def __init__(self, nb_arms, nb_rep, horizon):
        self.nb_arms = nb_arms
        self.nb_rep = nb_rep
        self.horizon = horizon
        
        self.choices = np.zeros([self.nb_rep, self.horizon])
        self.rewards = np.zeros([self.nb_rep, self.horizon])
        self.cum_rewards = np.zeros([self.nb_rep, self.horizon])
        self.stat_cum = np.zeros([2,self.horizon])
        self.nb_pulls = np.zeros([self.nb_arms, self.nb_rep])
#        self.stat_pull = np.zeros([2,self.horizon])

        
    def store_rewards(self, rep, t, choice, reward, nb_pull):
        self.choices[rep, t] = choice
        self.rewards[rep, t] = reward    
        self.nb_pulls[choice, rep] += nb_pull
        if t==0:
            self.cum_rewards[rep, t] = reward
        else:
            self.cum_rewards[rep, t] = self.cum_rewards[rep, t-1] + reward
        
    def calculate_stat_rewards(self):
#        print(self.cum_rewards)
        self.stat_cum[0,:] = np.mean(self.cum_rewards,axis=0)
        self.stat_cum[1,:] = np.sqrt(np.var(self.cum_rewards,axis=0))
    
#    def store_probability_error(self, epoch):
#        self.probability_error[epoch] = sum(self.rewards[epoch,:])/float(self.nb_rep)
#
#    def store_probability_stat(self):
#        self.probability_stat[0] = np.mean(self.probability_error)
#        self.probability_stat[1] = np.sqrt(np.var(self.probability_error))
#        
#    def store_sample_complexity(self, epoch):
#        self.sample_complexity[epoch] = sum(self.nb_pulls[epoch,:])/float(self.nb_rep)
#        
#    def store_sample_complexity_stat(self):
#        self.sample_complexity_stat[0] = np.mean(self.sample_complexity)
#        self.sample_complexity_stat[1] = np.sqrt(np.var(self.sample_complexity))    
    