# -*- coding: utf-8 -*-

import datetime # to show the date and time
import timeit # to calculate the time consumption
import os  # to save files

import random as rand
import numpy as np
from matplotlib.pyplot import *

#from data.Load import Load
from data.LoadArmParameter import LoadArmParameter
from environment.MAB import MAB
from evaluation.Evaluation import Evaluation

from policy.LinUCB import LinUCB
from policy.LinCRT import LinCRT
from policy.LinMoM import LinMoM
from policy.MENU import MENU
from policy.TOFU import TOFU

#from policy.MABEA import MABEA
#from policy.MABTEA import MABTEA

from policy.posterior.Beta import Beta
from policy.posterior.GaussianPosterior import GaussianPosterior

from plotSetting.FigureSetting import FigureSetting

# graphic setting
graphic = 'yes'

# running setting
nb_rep = 10# 10  
horizon = 20000 # to plot a figure, the horizon must be larger than 150

##############################

if graphic == 'yes':
    start_point = 1000
    number_point = 20
    
    bar_width = 0.1
    opacity = 0.9
    f = FigureSetting(graphic)
    f.color()
    cols = f.colors
    f.marker()
    mas = f.markers
    figure(1)

data = LoadArmParameter()
print('#arms: '+str(data.nb_arms))
print('#features: '+str(data.nb_features))
print('#repetitions: '+str(nb_rep))  
print('#horizon: '+str(horizon))
print("b: "+str(data.B))
print("c: "+str(data.C))

env = MAB(data, nb_rep, horizon)
best = env.best_arm_payoff()
worst = env.worst_arm_payoff()

policies = [LinMoM(data.nb_arms, data.nb_features),MENU(data.nb_arms, data.nb_features)]

plot_ret_mean = np.zeros([len(policies), horizon])
plot_ret_std = np.zeros([len(policies), horizon])
time_con = []    
k=0

for policy in policies:
    print("===============================")
    print(policy)
    print(datetime.datetime.now())
    time_begin = timeit.default_timer()
    game = Evaluation(env, policy, nb_rep, horizon)
    
    result = game.play(policy)
    
    time_end = timeit.default_timer()
    time_con.append(time_end-time_begin)
    
#    print("select arm: ", result.choices)
#    print("cum rewards: ", result.stat_cum)
    print("best arm: ", best)
    print("optimal payoffs: ", np.dot(best[1],horizon))
    print("worst arm: ", worst)
    print("worst payoffs: ", np.dot(worst[1],horizon))
    print("-------------------------------")
    print(policy)
    print("time consumption: ", time_end-time_begin)
    print("policy performance [mean of final reward, std of final reward]: ")
    print([result.stat_cum[0,-1],result.stat_cum[1,-1]])
    print("===============================")
    print("\n")
    plot_ret_mean[k,:] = result.stat_cum[0,:]
    plot_ret_std[k,:] = result.stat_cum[1,:]
    k = k+1
    
time_id = str(datetime.datetime.now())
time_id = time_id.replace(':','.')
time_id = time_id.replace(' ','-')
os.makedirs(os.path.dirname('results/data/'+str(time_id)+'/'), exist_ok=True)
os.makedirs(os.path.dirname('results/figure/'), exist_ok=True)

k = 0
tsav = np.int_(np.linspace(start_point,horizon-1,number_point))
for obj in policies:
    # save data
    filename = str(obj.name)
    with open('results/data/'+str(time_id)+'/stat_'+filename+'.txt','w') as f:
        f.writelines(str(time_id)+'\n')
        f.writelines(str(obj.name)+'\n')
        f.writelines('#arms: '+str(data.nb_arms)+'\n')
        f.writelines('#features: '+str(data.nb_features)+'\n')
        f.writelines('#repetitions: '+str(nb_rep)+'\n')
        f.writelines('#horizon: '+str(horizon)+'\n')
        
        f.writelines('\n')
        f.writelines("++++++++++ cumulative rewards ++++++++++"+'\n')
        f.writelines("best arm: payoff"+'\n')
        f.writelines(str(best[0])+': '+str(best[1])+'\n')
        f.writelines("optimal payoffs: "+str(np.dot(best[1],horizon))+'\n')
        f.writelines("mean of final reward: ")
        f.writelines(str(plot_ret_mean[k,-1]))
        f.writelines('\n')
        f.writelines("std of final reward: ")
        f.writelines(str(plot_ret_std[k,-1]))
        f.writelines('\n')
        f.writelines("========== cumulative rewards =========="+'\n')
        
    with open('results/data/'+str(time_id)+'/results_'+filename+'.txt','w') as f:
        f.writelines(str(time_id)+'\n')
        f.writelines(str(obj.name)+'\n')
        f.writelines('#arms: '+str(data.nb_arms)+'\n')
        f.writelines('#features: '+str(data.nb_features)+'\n')
        f.writelines('#repetitions: '+str(nb_rep)+'\n')
        f.writelines('#horizon: '+str(horizon)+'\n')
        f.writelines("best arm: payoff"+'\n')
        f.writelines(str(best[0])+': '+str(best[1])+'\n')
        f.writelines("optimal payoffs: "+str(np.dot(best[1],horizon))+'\n')
        
        f.writelines('\n')
        f.writelines("++++++++++ time consumption ++++++++++"+'\n')
        f.writelines("(second)" + '\n')
        f.writelines(str(time_con[k]))
        f.writelines('\n')
        f.writelines("========== end of time consumption =========="+'\n')
        
        f.writelines('\n')
        f.writelines("++++++++++ cumulative rewards ++++++++++"+'\n')
        f.writelines("mean: " + '\n')
        f.writelines(["%s " % item  for item in plot_ret_mean[k,:]])
        f.writelines('\n')
        f.writelines("standard deviation: "+'\n')
        f.writelines(["%s " % item  for item in plot_ret_std[k,:]])
        f.writelines('\n')
        f.writelines("mean of final reward: ")
        f.writelines(str(plot_ret_mean[k,-1]))
        f.writelines('\n')
        f.writelines("std of final reward: ")
        f.writelines(str(plot_ret_std[k,-1]))
        f.writelines('\n')
        f.writelines("========== cumulative rewards =========="+'\n')
        
    # plot figure
    plot_ret = plot_ret_mean[k, tsav]
    plot_std = plot_ret_std[k, tsav]
    plot_horizon = np.array([h for h in range(horizon)])
    if graphic == 'yes':
        matplotlib.rcParams.update({'font.size': 14})
        ax = gca()
        
        #plt.bar(ps, plot_mean[:,k], bar_width, alpha=opacity,color=cols[k], marker = mas[k],yerr=plot_std[:,k], error_kw=dict(ecolor='grey', lw=2, capsize=5, capthick=2))

        plot(plot_horizon[tsav], plot_ret, color = cols[k], marker = mas[k])
#        semilogy(plot_horizon[tsav], plot_ret, color = cols[k], marker = mas[k])
        ax.errorbar(plot_horizon[tsav], plot_ret, yerr=plot_std, fmt='none',ecolor=cols[k], capsize=3, label='_nolegend_')
        ax.ticklabel_format(style='sci', axis='both',scilimits=(1,3))
#        ax.set_xscale('log')
        ylabel('Cumulative Payoffs')
        xlabel('Rounds')
#        ax.ticklabel_format(style='sci', axis='y')
    k += 1
            
# save figure
if graphic == 'yes':
    matplotlib.rcParams.update({'legend.labelspacing':0.25})
    matplotlib.rcParams.update({'font.size': 14})
    legend_name = [obj.name for obj in policies]
    legend(legend_name, loc='best')
    savefig('results/figure/'+str(time_id)+'.eps',bbox_inches='tight', dpi = 300)
    show()