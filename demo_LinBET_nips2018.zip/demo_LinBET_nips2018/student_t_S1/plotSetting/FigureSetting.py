# -*- coding: utf-8 -*-

class FigureSetting:
	def __init__(self, sign):
		self.colors = []
		self.markers = []
		self.graphic = sign #'yes'
		
	def color(self):
		self.colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'black', 'yellow', 'red']
	
	def marker(self):
		self.markers = ['+','o','>','<','^','v','*','x'] 